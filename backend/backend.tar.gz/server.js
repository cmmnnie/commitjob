// backend/server.js
//import swaggerUi from "swagger-ui-express";
//import YAML from "yamljs";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import dotenv from "dotenv";
import axios from "axios";
import multer from "multer";
import * as jose from "jose";
import crypto from "crypto";
import path from 'path';
import fs from 'fs';

// Removed: Advanced Recommendation Algorithms (replaced with GPT MCP)



dotenv.config();
const app = express();
// ✨ 안전한 포트/호스트 결정
const PORT = Number(process.env.PORT || 4001);

// 모든 네트워크 인터페이스에서 접근 가능하도록 설정 (프론트엔드 팀 접근용)
const HOST = process.env.HOST || '0.0.0.0';

// 중복 listen 방지 - 혹시 다른 곳에서 httpServer.listen을 또 호출하면 에러 띄우게
if (!app._listening) {
  const server = app.listen(PORT, HOST, () => {
    console.log(`[BOOT] Listening on http://${HOST}:${PORT} (NODE_ENV=${process.env.NODE_ENV || 'undefined'})`);
  });
  app._listening = true;

  // 프로세스 진짜로 리스닝 중인지 1초 뒤에도 로그
  setTimeout(() => {
    console.log(`[HEALTH] server.listening=${server.listening}`);
  }, 1000);
}

// --- Swagger UI ---
import swaggerUi from 'swagger-ui-express';
import swaggerJsdoc from 'swagger-jsdoc';

const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'CommitJob Backend API',
      version: '1.0.0',
      description: 'CommitJob 백엔드 API - 소셜 로그인, GPT MCP 기반 맞춤형 채용공고 추천 및 면접 질문 생성',
    },
    servers: [
      {
        url: 'http://172.30.1.28:4001',
        description: 'Development server (IP)',
      },
      {
        url: 'http://api.commitjob.site:4001',
        description: 'Development server (Domain)',
      },
      {
        url: 'http://localhost:4001',
        description: 'Local development',
      },
    ],
    components: {
      securitySchemes: {
        cookieAuth: {
          type: 'apiKey',
          in: 'cookie',
          name: 'app_session'
        }
      },
      schemas: {
        User: {
          type: 'object',
          properties: {
            id: { type: 'integer', example: 1 },
            email: { type: 'string', nullable: true, example: 'user@example.com' },
            name: { type: 'string', nullable: true, example: '홍길동' },
            picture: { type: 'string', nullable: true, example: 'https://example.com/avatar.png' },
            provider: { type: 'string', enum: ['google', 'kakao'], example: 'google' }
          }
        },
        UserProfile: {
          type: 'object',
          properties: {
            user_id: { type: 'integer', example: 1, description: '사용자 ID' },
            jobs: { type: 'string', example: '백엔드 개발자', description: '희망직무' },
            careers: { type: 'string', example: '1-3년', description: '경력' },
            regions: { type: 'string', example: '서울', description: '희망근무지역' },
            skills: { type: 'array', items: { type: 'string' }, example: ['JavaScript', 'React', 'Node.js'], description: '기술스택' },
            resume_path: { type: 'string', example: '/uploads/resume/1_20250922.pdf', description: '자기소개서 파일 경로' },
            created_at: { type: 'string', format: 'date-time', description: '생성일시' },
            updated_at: { type: 'string', format: 'date-time', description: '수정일시' }
          },
          required: ['user_id']
        },
        Ok: {
          type: 'object',
          properties: {
            ok: { type: 'boolean', example: true }
          }
        },
        Error: {
          type: 'object',
          properties: {
            error: {
              type: 'object',
              properties: {
                code: { type: 'string', example: 'INVALID_STATE' },
                message: { type: 'string', example: 'state mismatch' }
              }
            }
          }
        }
      }
    }
  },
  apis: ['./server.js', './openapi.yaml'], // 현재 파일과 기존 YAML 파일에서 읽음
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);

// JSON 스펙 제공
app.get('/api/docs/swagger.json', (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.send(swaggerSpec);
});

// Swagger UI 설정
const swaggerUiOptions = {
  explorer: true,
  swaggerOptions: {
    url: '/api/docs/swagger.json'
  }
};

app.use('/api/docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec, swaggerUiOptions));

/* -------------------- 기본 설정 -------------------- */
app.use(cookieParser());
app.use(express.json());

// --- 파일 업로드 (multer) ---

// 프로필 업로드용 (디스크)
const resumeDir = path.join(process.cwd(), 'uploads', 'resume');
fs.mkdirSync(resumeDir, { recursive: true });

const uploadDir = path.join(process.cwd(), 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });

const diskStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const userId = req.body.user_id || 'unknown';
    const ext = path.extname(file.originalname || '.pdf');
    cb(null, `${userId}_${Date.now()}${ext}`);
  }
});
const uploadProfile = multer({ storage: diskStorage });

// 세션 인제스트용 (메모리)
const uploadMem = multer({ storage: multer.memoryStorage() });
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));
// --- MySQL 풀 ---
import mysql from 'mysql2/promise';
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
  connectionLimit: 10
});


// 프록시 환경에서 secure 쿠키 판단용
app.set("trust proxy", 1);

// 예: backend/server.js 어딘가(다른 라우트들 아래쪽이면 OK)
app.get('/api/health', (req, res) => {
  res.status(200).json({ status: 'ok', message: 'Backend is healthy!' });
});


// 미들웨어들(app.use(express.json()), cors 등) 다음 줄에 추가
app.get(['/health', '/api/health', '/auth/health'], (req, res) => {
  res.status(200).json({ status: 'ok', message: 'Backend is healthy!' });
});


// 여러 프론트 오리진 허용
const allowedOrigins = (process.env.FRONTEND_ORIGIN || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);


console.log("[CORS] Initial allowedOrigins (on startup) =", allowedOrigins); // 시작 시점에 확인
// 운영/로컬 둘 다 안전하게 기본값 보강
if (allowedOrigins.length === 0) {
  allowedOrigins.push(
    'https://commitjob.site',
    'https://www.commitjob.site',
    'http://localhost:3000',
    'http://localhost:5173',
    'http://localhost:5174',
    'http://commitjob.site'
  );
}
// state 보관 (google/kakao 공용)
const stateStore = new Map(); // state -> origin

const corsOptions = {
  origin: function (origin, callback) {
    console.log(`[CORS Check] Incoming origin: "${origin}" (length: ${origin ? origin.length : 0})`);
    console.log(`[CORS Check] allowedOrigins used in callback: `, allowedOrigins);

    if (!origin) {
      console.log('[CORS Check] No origin (server-to-server or terminal test). Allowed.');
      return callback(null, true); // 서버-서버 / curl 허용
    }

    // LocalTunnel URL 허용 (*.loca.lt)
    if (origin.endsWith('.loca.lt')) {
      console.log(`[CORS Check] LocalTunnel origin "${origin}" allowed.`);
      return callback(null, true);
    }

    if (allowedOrigins.includes(origin)) {
      console.log(`[CORS Check] Origin "${origin}" found in allowed list. Allowed.`);
      return callback(null, true);
    }

    console.error(`[CORS Check] ERROR: Origin "${origin}" NOT found in allowed list! Disallowed.`);
    return callback(new Error(`Not allowed by CORS: ${origin}`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Set-Cookie'],
  optionsSuccessStatus: 204,
};
console.log("[CORS] allowedOrigins =", allowedOrigins);
// --- CORS 미들웨어는 "반드시" 라우트보다 먼저
app.use(cors(corsOptions));
/* -------------------- 임시 유저 저장소 -------------------- */

// --- DB 기반 사용자 관리 함수들 ---
async function findOrCreateUser(providerKey, email, name, picture, provider) {
  try {
    // 기존 사용자 찾기
    const [existingUsers] = await pool.execute(
      'SELECT * FROM users WHERE provider_key = ?',
      [providerKey]
    );

    if (existingUsers.length > 0) {
      // 기존 사용자 정보 업데이트
      const user = existingUsers[0];
      await pool.execute(
        'UPDATE users SET email = ?, name = ?, picture = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
        [email, name, picture, user.id]
      );
      return { ...user, email, name, picture };
    } else {
      // 새 사용자 생성
      const [result] = await pool.execute(
        'INSERT INTO users (provider_key, email, name, picture, provider) VALUES (?, ?, ?, ?, ?)',
        [providerKey, email, name, picture, provider]
      );
      return {
        id: result.insertId,
        provider_key: providerKey,
        email,
        name,
        picture,
        provider
      };
    }
  } catch (error) {
    console.error('[DB] Error in findOrCreateUser:', error);
    throw error;
  }
}

async function findUserById(userId) {
  try {
    const [users] = await pool.execute(
      'SELECT * FROM users WHERE id = ?',
      [userId]
    );
    return users.length > 0 ? users[0] : null;
  } catch (error) {
    console.error('[DB] Error in findUserById:', error);
    throw error;
  }
}

// 세션(개인화용) 저장소
const sessions = new Map(); // sessionId -> { user:{}, jobs:[], companies:[] }
const newSessionId = () => crypto.randomUUID();
const ensureSession = sid => {
  if (!sid || !sessions.has(sid)) throw new Error("NO_SESSION");
  return sessions.get(sid);
};

/* -------------------- 1) 구글 로그인 시작 ------------------ */
app.get("/auth/google", (req, res) => {
  const origin = req.query.origin?.toString();
  if (!origin || !allowedOrigins.includes(origin)) {
    return res.status(400).send("Bad origin");
  }
  const state = crypto.randomUUID();
  stateStore.set(state, origin);

  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID,
    redirect_uri: process.env.GOOGLE_REDIRECT_URI,
    response_type: "code",
    scope: "openid email profile",
    include_granted_scopes: "true",
    state,
    prompt: "select_account",
    access_type: "offline",
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`);
});

/* --------- 2) 구글 콜백: code→token, 검증, 세션 쿠키 ------- */
app.get("/auth/google/callback", async (req, res) => {
  const fallback = allowedOrigins[0] || "http://localhost:5173";
  try {
    const { code, state } = req.query;

    const origin = stateStore.get(state);
    stateStore.delete(state);
    if (!origin) return res.status(403).json({ error: "INVALID_STATE" });

    const tokenRes = await axios.post(
      "https://oauth2.googleapis.com/token",
      {
        code,
        client_id: process.env.GOOGLE_CLIENT_ID,
        client_secret: process.env.GOOGLE_CLIENT_SECRET,
        redirect_uri: process.env.GOOGLE_REDIRECT_URI,
        grant_type: "authorization_code",
      },
      { headers: { "Content-Type": "application/json" } }
    );

    const { id_token } = tokenRes.data;

    const JWKS = jose.createRemoteJWKSet(new URL("https://www.googleapis.com/oauth2/v3/certs"));
    const { payload } = await jose.jwtVerify(id_token, JWKS, {
      issuer: ["https://accounts.google.com", "accounts.google.com"],
      audience: process.env.GOOGLE_CLIENT_ID,
    });

    const email = payload.email ?? null;
    const name = payload.name ?? null;
    const picture = payload.picture ?? null;
    const sub = payload.sub;

    const providerKey = `google:${sub}`;
    const user = await findOrCreateUser(providerKey, email, name, picture, 'google');
    const uid = user.id;

    const appJwt = await new jose.SignJWT({ uid, email, provider: "google" })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("7d")
      .sign(new TextEncoder().encode(process.env.JWT_SECRET));

    const isProd = process.env.NODE_ENV === "production";
    res.cookie("app_session", appJwt, {
      httpOnly: true,
      secure: isProd,
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: "/",
    });

    res.redirect(`${origin}/auth/callback?ok=1`);
  } catch (e) {
    console.error(e.response?.data || e);
    res.redirect(`${fallback}/auth/callback?ok=0`);
  }
});

/* -------------------- 1-2) 카카오 로그인 시작 ------------------ */
app.get("/auth/kakao", (req, res) => {
  const origin = req.query.origin?.toString();
  if (!origin || !allowedOrigins.includes(origin)) {
    return res.status(400).send("Bad origin");
  }
  const state = crypto.randomUUID();
  stateStore.set(state, origin);

  const params = new URLSearchParams({
    client_id: process.env.KAKAO_REST_API_KEY,
    redirect_uri: process.env.KAKAO_REDIRECT_URI,
    response_type: "code",
    state,
    scope: "profile_nickname profile_image account_email",
  });
  res.redirect(`https://kauth.kakao.com/oauth/authorize?${params.toString()}`);
});

// 조정된 app.get("/auth/kakao/login-url") 라우트
app.get("/auth/kakao/login-url", (req, res) => {
  // 프론트엔드가 이 URL을 요청할 때 자신의 origin을 쿼리 파라미터로 전달해야 합니다.
  // 예: /auth/kakao/login-url?origin=http://localhost:5173
  const origin = req.query.origin?.toString(); 
  if (!origin || !allowedOrigins.includes(origin)) {
    return res.status(400).json({ error: "Bad origin or missing origin query parameter" }); // JSON 응답으로 변경
  }

  const state = crypto.randomUUID();
  stateStore.set(state, origin); // 생성된 state와 프론트엔드의 origin을 연결하여 저장

  const params = new URLSearchParams({
    client_id: process.env.KAKAO_REST_API_KEY,
    redirect_uri: process.env.KAKAO_REDIRECT_URI,
    response_type: "code",
    state, // 이 state 값을 카카오 인가 URL에 포함
    scope: "profile_nickname profile_image account_email",
  });
  const url = `https://kauth.kakao.com/oauth/authorize?${params.toString()}`;
  
  // 프론트엔드에 카카오 인가 URL과 함께 생성된 state 값을 반환합니다.
  res.json({ url, state }); 
});



/* --------- 2) 카카오 콜백: code→token, 사용자 조회, 세션 쿠키 ------- */
app.get("/auth/kakao/callback", async (req, res) => {
  const fallback = allowedOrigins[0] || "http://localhost:5173";
  try {
    const { code, state } = req.query;

    const origin = stateStore.get(state);
    stateStore.delete(state);
    if (!origin) return res.status(403).json({ error: "INVALID_STATE" });

    const form = new URLSearchParams({
      grant_type: "authorization_code",
      client_id: process.env.KAKAO_REST_API_KEY,
      redirect_uri: process.env.KAKAO_REDIRECT_URI,
      code: String(code),
    });
    if (process.env.KAKAO_CLIENT_SECRET) {
      form.set("client_secret", process.env.KAKAO_CLIENT_SECRET);
    }

    const tokenRes = await axios.post(
      "https://kauth.kakao.com/oauth/token",
      form.toString(),
      { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
    );

    const { access_token } = tokenRes.data;

    const meRes = await axios.get("https://kapi.kakao.com/v2/user/me", {
      headers: { Authorization: `Bearer ${access_token}` },
    });

    const kakao = meRes.data;
    const sub = kakao.id?.toString();
    const emailRaw = kakao.kakao_account?.email ?? null;
    const email = emailRaw ?? (sub ? `kakao_${sub}@no-email.kakao` : null);
    const name = kakao.kakao_account?.profile?.nickname ?? null;
    const picture = kakao.kakao_account?.profile?.profile_image_url ?? null;

    const providerKey = `kakao:${sub}`;
    const user = await findOrCreateUser(providerKey, email, name, picture, 'kakao');
    const uid = user.id;

    const appJwt = await new jose.SignJWT({ uid, email, provider: "kakao" })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("7d")
      .sign(new TextEncoder().encode(process.env.JWT_SECRET));

    const isProd = process.env.NODE_ENV === "production";
    res.cookie("app_session", appJwt, {
      httpOnly: true,
      secure: isProd,
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: "/",
    });

    res.redirect(`${origin}/auth/callback?ok=1`);
  } catch (e) {
    console.error("KAKAO_AUTH_FAIL", {
      msg: e.message,
      data: e.response?.data,
      status: e.response?.status,
    });
    res.redirect(`${fallback}/auth/callback?ok=0`);
  }
});

/* ==================== 세션 공통 ==================== */
app.get("/api/me", async (req, res) => {
  try {
    const cookie = req.cookies?.app_session;
    if (!cookie) return res.status(401).json({ user: null });

    const { payload } = await jose.jwtVerify(
      cookie,
      new TextEncoder().encode(process.env.JWT_SECRET)
    );

    const user = await findUserById(payload.uid);
    if (!user) return res.status(401).json({ user: null });

    res.json({ user: { ...user, provider: payload.provider } });
  } catch {
    res.status(401).json({ user: null });
  }
});

app.post("/api/logout", (req, res) => {
  res.clearCookie("app_session", { path: "/" });
  res.json({ ok: true });
});

/* ==================== 세션/프로필/인제스트 ==================== */
app.post("/session/start", (req, res) => {
  const sid = newSessionId();
  sessions.set(sid, { user: null, jobs: [], companies: [] });
  res.json({ sessionId: sid });
});

app.post('/api/profile', uploadProfile.single('resume'), async (req, res) => {
  try {
    const {
      user_id,
      jobs,
      careers,
      regions,
      skills
    } = req.body || {};

    if (!user_id) {
      return res.status(400).json({ error: { code: "MISSING_USER_ID", message: "user_id is required" } });
    }

    // 사용자 존재 확인
    const user = await findUserById(user_id);
    if (!user) {
      return res.status(404).json({ error: { code: "USER_NOT_FOUND", message: "User not found" } });
    }

    // 파일 경로 처리
    let resumePath = null;
    if (req.file) {
      resumePath = `/uploads/resume/${req.file.filename}`;
    }

    // 기존 프로필 확인
    const [existingProfiles] = await pool.execute(
      'SELECT * FROM user_profiles WHERE user_id = ?',
      [user_id]
    );

    if (existingProfiles.length > 0) {
      // 프로필 업데이트
      const updateFields = [];
      const updateValues = [];

      if (jobs) {
        updateFields.push('preferred_jobs = ?');
        updateValues.push(jobs);
      }
      if (careers) {
        updateFields.push('experience = ?');
        updateValues.push(careers);
      }
      if (regions) {
        updateFields.push('preferred_regions = ?');
        updateValues.push(JSON.stringify([regions]));
      }
      if (skills) {
        updateFields.push('skills = ?');
        updateValues.push(JSON.stringify(skills.split(',').map(s => s.trim())));
      }
      if (resumePath) {
        updateFields.push('resume_path = ?');
        updateValues.push(resumePath);
      }

      updateFields.push('updated_at = CURRENT_TIMESTAMP');
      updateValues.push(user_id);

      await pool.execute(
        `UPDATE user_profiles SET ${updateFields.join(', ')} WHERE user_id = ?`,
        updateValues
      );
    } else {
      // 새 프로필 생성
      await pool.execute(
        'INSERT INTO user_profiles (user_id, preferred_jobs, experience, preferred_regions, skills, resume_path) VALUES (?, ?, ?, ?, ?, ?)',
        [user_id, jobs, careers, JSON.stringify([regions]), skills ? JSON.stringify(skills.split(',').map(s => s.trim())) : null, resumePath]
      );
    }

    // 업데이트된 프로필 조회
    const [profiles] = await pool.execute(
      'SELECT * FROM user_profiles WHERE user_id = ?',
      [user_id]
    );

    const profile = profiles[0];

    res.status(201).json({
      user_id: profile.user_id,
      jobs: profile.preferred_jobs,
      careers: profile.experience,
      regions: profile.preferred_regions ? JSON.parse(profile.preferred_regions)[0] : null,
      skills: profile.skills ? JSON.parse(profile.skills) : null,
      resume_path: profile.resume_path,
      created_at: profile.created_at,
      updated_at: profile.updated_at
    });
  } catch (e) {
    res
      .status(400)
      .json({ error: { code: e.message || "BAD_INPUT", message: "profile set failed" } });
  }
});

app.post("/session/ingest/files", uploadMem.array("files", 10), async (req, res) => {
  try {
    const { sessionId } = req.body || {};
    const s = ensureSession(sessionId);
    if (!req.files?.length) return res.status(400).json({ error: { code: "NO_FILES" } });

    const added = [];
    for (const f of req.files) {
      // Node 18+ 글로벌 fetch/FormData/Blob 사용
      const form = new FormData();
      form.append("file", new Blob([f.buffer]), f.originalname);

      const r = await fetch(`${process.env.MCP_INGEST_BASE}/tools/extract_file_and_normalize`, {
        method: "POST",
        body: form,
      }).then(_ => _.json());

      const job = r?.normalizedJob;
      if (!job) continue;

      const isCompanyDoc = /회사 소개|기업 소개|culture|value|vision|연봉 보고서|리포트/i.test(
        (job.title || "") + " " + (job.description || "")
      );

      if (!isCompanyDoc) {
        const job_id = `${(job.company || "unknown").toLowerCase().replace(/\s+/g, "-")}_${Date.now()}`;
        const company_id = (job.company || "unknown").toLowerCase().replace(/\s+/g, "-");
        s.jobs.push({ ...job, job_id, company_id, source: "file" });
        added.push({ type: "job", job_id, title: job.title, company: job.company });
      } else {
        const company_id = (job.company || "unknown").toLowerCase().replace(/\s+/g, "-");
        s.companies.push({
          company_id,
          name: job.company || "기업",
          overview: job.description || null,
          culture: null,
          values: null,
          scores: null,
          review_highlights: null,
        });
        added.push({ type: "company", company_id, name: job.company || "기업" });
      }
    }

    res.json({ ok: true, added, counts: { jobs: s.jobs.length, companies: s.companies.length } });
  } catch (e) {
    console.error(e);
    res.status(400).json({ error: { code: "INGEST_FAILED", message: "file ingest failed" } });
  }
});

app.post("/session/ingest/url", async (req, res) => {
  try {
    const { sessionId, url } = req.body || {};
    const s = ensureSession(sessionId);
    if (!url) return res.status(400).json({ error: { code: "NO_URL" } });

    const { data } = await axios.post(
      `${process.env.MCP_INGEST_BASE}/tools/fetch_url_and_normalize`,
      { url }
    );
    const job = data?.normalizedJob;
    if (!job) return res.status(415).json({ error: { code: "PARSE_FAIL" } });

    const job_id = `${(job.company || "unknown").toLowerCase().replace(/\s+/g, "-")}_${Date.now()}`;
    const company_id = (job.company || "unknown").toLowerCase().replace(/\s+/g, "-");
    s.jobs.push({ ...job, job_id, company_id, source: "url", source_url: url });

    res.json({ ok: true, job_id, title: job.title, company: job.company });
  } catch (e) {
    res.status(500).json({ error: { code: "INGEST_URL_FAILED" } });
  }
});

/* -------------------- 맞춤 추천 -------------------- */
function skillMatchScore(userSkills, jobSkills) {
  if (!Array.isArray(userSkills) || !Array.isArray(jobSkills)) return 0;
  const set = new Set(jobSkills.map(s => String(s).toLowerCase()));
  const inter = userSkills.filter(s => set.has(String(s).toLowerCase())).length;
  return inter / Math.max(1, userSkills.length);
}
function yearsFit(userYears, min, max) {
  if (userYears == null || min == null || max == null) return 0.5;
  if (userYears < min - 1 || userYears > max + 1) return 0;
  if (userYears >= min && userYears <= max) return 1;
  return 0.5;
}
function regionFit(userRegion, jobRegion) {
  if (!userRegion || !jobRegion) return 0.5;
  return jobRegion.includes(userRegion) ? 1 : 0.5;
}

app.get("/session/recs", async (req, res) => {
  try {
    const { sessionId, top = 20 } = req.query;
    const s = ensureSession(String(sessionId));
    if (!s.user) return res.status(400).json({ error: { code: "NO_USER_PROFILE" } });
    if (!s.jobs.length) return res.json({ items: [] });

    const candidates = s.jobs
      .map(j => {
        const f_skill = skillMatchScore(s.user.skills || [], j.skills || []);
        const f_years = yearsFit(s.user.years, j.years_min, j.years_max);
        const f_region = regionFit(s.user.region, j.region);
        const f_text = 0.7; // MVP 더미
        const score_v1 = 0.4 * f_skill + 0.25 * f_text + 0.15 * f_years + 0.1 * f_region + 0.1 * 0;
        return {
          job_id: j.job_id,
          company_id: j.company_id,
          title: j.title,
          skills: j.skills || [],
          region: j.region || null,
          years_min: j.years_min ?? null,
          years_max: j.years_max ?? null,
          description: j.description || "",
          score_v1: Number(score_v1.toFixed(4)),
        };
      })
      .sort((a, b) => b.score_v1 - a.score_v1)
      .slice(0, 100);

    const { data } = await axios.post(
      `${process.env.MCP_RECS_BASE}/tools/rerank_jobs`,
      {
        sessionId: String(sessionId),
        user: { skills: s.user.skills, years: s.user.years, region: s.user.region, role: s.user.role },
        candidates,
        topK: Math.min(Number(top) || 20, 50),
      },
      { timeout: 20000 }
    );

    const ranked = (data?.ranked || []).map(r => {
      const base = candidates.find(c => c.job_id === r.job_id) || {};
      return { ...base, finalScore: r.finalScore, reason: r.reason };
    });

    res.json({ items: ranked });
  } catch (e) {
    console.error("RECS_FAILED", e.response?.data || e.message);
    res.status(500).json({ error: { code: "RECS_FAILED" } });
  }
});


/**
 * @swagger
 * /api/main-recommendations:
 *   get:
 *     summary: 메인 페이지용 맞춤 IT/빅데이터 추천
 *     tags: [GPT Recommendations]
 *     parameters:
 *       - in: query
 *         name: user_id
 *         required: true
 *         schema:
 *           type: integer
 *         description: 사용자 ID
 *       - in: query
 *         name: jobType
 *         schema:
 *           type: string
 *           enum: [IT, 빅데이터, 전체]
 *           default: 전체
 *         description: 추천할 직무 타입 (IT 10개, 빅데이터 10개)
 *     responses:
 *       200:
 *         description: 사용자 맞춤 메인 페이지 추천 결과
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 IT:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                         description: "[필수] 채용공고 ID"
 *                       title:
 *                         type: string
 *                         description: "[필수] 채용공고 제목"
 *                       company:
 *                         type: string
 *                         description: "[필수] 회사명"
 *                       location:
 *                         type: string
 *                         description: "[필수] 근무지역"
 *                       experience:
 *                         type: string
 *                         description: "[필수] 경력요건"
 *                       skills:
 *                         type: array
 *                         items:
 *                           type: string
 *                         description: "[필수] 요구 기술스택"
 *                       salary:
 *                         type: string
 *                         description: "[선택] 연봉 정보 (있는 경우만 포함)"
 *                     required: [id, title, company, location, experience, skills]
 *                   example:
 *                     - id: "job_123"
 *                       title: "백엔드 개발자 (Node.js)"
 *                       company: "네이버"
 *                       location: "서울"
 *                       experience: "1-3년"
 *                       skills: ["Node.js", "Express", "MySQL"]
 *                       salary: "3000-4500만원"
 *                     - id: "job_124"
 *                       title: "풀스택 개발자"
 *                       company: "카카오"
 *                       location: "판교"
 *                       experience: "신입-2년"
 *                       skills: ["React", "Node.js", "MongoDB"]
 *                 빅데이터:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                         description: "[필수] 채용공고 ID"
 *                       title:
 *                         type: string
 *                         description: "[필수] 채용공고 제목"
 *                       company:
 *                         type: string
 *                         description: "[필수] 회사명"
 *                       location:
 *                         type: string
 *                         description: "[필수] 근무지역"
 *                       experience:
 *                         type: string
 *                         description: "[필수] 경력요건"
 *                       skills:
 *                         type: array
 *                         items:
 *                           type: string
 *                         description: "[필수] 요구 기술스택"
 *                       salary:
 *                         type: string
 *                         description: "[선택] 연봉 정보 (있는 경우만 포함)"
 *                     required: [id, title, company, location, experience, skills]
 *                   example:
 *                     - id: "job_456"
 *                       title: "데이터 엔지니어"
 *                       company: "카카오"
 *                       location: "서울"
 *                       experience: "신입-2년"
 *                       skills: ["Python", "Spark", "Kafka"]
 *                       salary: "3500-5000만원"
 *                     - id: "job_457"
 *                       title: "ML 엔지니어"
 *                       company: "네이버"
 *                       location: "서울"
 *                       experience: "3-5년"
 *                       skills: ["Python", "TensorFlow", "Kubernetes"]
 *       500:
 *         description: 서버 오류
 */
app.get("/api/main-recommendations", async (req, res) => {
  try {
    const { user_id, jobType = '전체' } = req.query;

    if (!user_id) {
      return res.status(400).json({ error: { code: "MISSING_USER_ID" } });
    }

    console.log(`[MAIN-RECS] Requesting GPT MCP recommendations for user ${user_id}, jobType: ${jobType}`);

    // 사용자 프로필 정보 가져오기 (가능한 경우)
    let userProfile = null;
    if (global.userProfiles && global.userProfiles[user_id]) {
      userProfile = global.userProfiles[user_id];
    }

    // GPT MCP 서비스에 추천 요청 (rerank_jobs 엔드포인트 사용)
    try {
      // 먼저 후보 채용공고 목록 준비
      let allJobs = [];
      if (global.demoData) {
        allJobs = global.demoData.jobs.map(job => ({
          id: job.id,
          title: job.title,
          company: job.companyName,
          location: job.location,
          experience: job.experienceLevel || "신입",
          skills: job.requiredSkills || [],
          salary: job.salary,
          jobType: job.jobType
        }));
      }

      const mcpResponse = await axios.post(
        `${process.env.MCP_RECS_BASE}/tools/rerank_jobs`,
        {
          user_profile: userProfile || {
            skills: [],
            experience: "신입",
            preferred_regions: [],
            jobs: [],
            expected_salary: ""
          },
          candidates: allJobs.slice(0, 15), // 후보 목록 제한
          limit: 20
        },
        {
          timeout: 15000,
          headers: { 'Content-Type': 'application/json' }
        }
      );

      console.log(`[MAIN-RECS] GPT MCP response received for user ${user_id}`);

      if (mcpResponse.data && mcpResponse.data.success && mcpResponse.data.reranked_jobs) {
        const rerankedJobs = mcpResponse.data.reranked_jobs;

        console.log(`[MAIN-RECS] GPT reranked ${rerankedJobs.length} jobs for user ${user_id}`);

        // GPT 추천 결과를 IT와 빅데이터로 분류
        const itJobs = rerankedJobs.filter(job =>
          job.category === 'IT' ||
          job.jobType === 'IT' ||
          (job.skills && job.skills.some(skill =>
            ['JavaScript', 'Node.js', 'React', 'Vue.js', 'Java', 'Spring', 'Python', 'Django', 'Flask', 'C++', 'Unity', 'C#'].includes(skill)
          ))
        ).slice(0, 10);

        const bigDataJobs = rerankedJobs.filter(job =>
          job.category === '빅데이터' ||
          job.jobType === '빅데이터' ||
          (job.skills && job.skills.some(skill =>
            ['Python', 'R', 'Spark', 'Kafka', 'Hadoop', 'TensorFlow', 'PyTorch', 'SQL', 'MongoDB'].includes(skill)
          ))
        ).slice(0, 10);

        const response = {
          IT: itJobs,
          빅데이터: bigDataJobs
        };

        return res.json(response);
      }
    } catch (mcpError) {
      console.error("[MAIN-RECS] GPT MCP service error:", mcpError.response?.data || mcpError.message);
      console.log("[MAIN-RECS] Falling back to demo data");
    }

    // GPT MCP 서비스 실패 시 데모 데이터 폴백
    let allJobs = [];
    if (global.demoData) {
      allJobs = global.demoData.jobs.map(job => ({
        id: job.id,
        title: job.title,
        company: job.companyName,
        location: job.location,
        experience: job.experienceLevel || "신입",
        skills: job.requiredSkills || [],
        salary: job.salary,
        jobType: job.jobType
      }));
    }

    if (!allJobs.length) {
      return res.json({ IT: [], 빅데이터: [] });
    }

    // 데모 데이터를 IT와 빅데이터로 분류
    const itJobs = allJobs.filter(job =>
      job.jobType === 'IT' ||
      job.skills.some(skill =>
        ['JavaScript', 'Node.js', 'React', 'Vue.js', 'Java', 'Spring', 'Python', 'Django', 'Flask'].includes(skill)
      )
    ).slice(0, 10);

    const bigDataJobs = allJobs.filter(job =>
      job.jobType === '빅데이터' ||
      job.skills.some(skill =>
        ['Python', 'R', 'Spark', 'Kafka', 'Hadoop', 'TensorFlow', 'PyTorch', 'SQL', 'MongoDB'].includes(skill)
      )
    ).slice(0, 10);

    const response = {
      IT: itJobs,
      빅데이터: bigDataJobs
    };

    res.json(response);

  } catch (e) {
    console.error("[MAIN-RECS] Error:", e.response?.data || e.message);
    res.status(500).json({ error: { code: "MAIN_RECS_FAILED" } });
  }
});

/* -------------------- 기업 정보 API -------------------- */
// 기업 종합 정보 API
app.post("/api/company-info", async (req, res) => {
  try {
    const { company_name } = req.body;

    if (!company_name) {
      return res.status(400).json({ error: { code: "MISSING_COMPANY_NAME" } });
    }

    console.log(`[COMPANY_INFO] Requesting info for: ${company_name}`);

    const response = await axios.post(
      `${process.env.MCP_RECS_BASE}/tools/get_company_reviews`,
      { company_name },
      { timeout: 10000 }
    );

    if (response.data && response.data.success) {
      res.json({
        success: true,
        company_name,
        data: response.data,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({ error: { code: "COMPANY_INFO_FAILED" } });
    }

  } catch (error) {
    console.error("[COMPANY_INFO] Error:", error.message);
    res.status(500).json({ error: { code: "COMPANY_INFO_FAILED" } });
  }
});

// 합격 자소서 정보 API
app.post("/api/job-essays", async (req, res) => {
  try {
    const { company_name, job_position } = req.body;

    if (!company_name) {
      return res.status(400).json({ error: { code: "MISSING_COMPANY_NAME" } });
    }

    console.log(`[JOB_ESSAYS] Requesting essays for: ${company_name} - ${job_position || 'All positions'}`);

    const response = await axios.post(
      `${process.env.MCP_RECS_BASE}/tools/get_job_essays`,
      { company_name, job_position },
      { timeout: 10000 }
    );

    if (response.data && response.data.success) {
      res.json({
        success: true,
        company_name,
        job_position: job_position || 'All positions',
        data: response.data,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({ error: { code: "JOB_ESSAYS_FAILED" } });
    }

  } catch (error) {
    console.error("[JOB_ESSAYS] Error:", error.message);
    res.status(500).json({ error: { code: "JOB_ESSAYS_FAILED" } });
  }
});

// 지원 꿀팁 정보 API
app.post("/api/job-tips", async (req, res) => {
  try {
    const { company_name, job_position } = req.body;

    if (!company_name) {
      return res.status(400).json({ error: { code: "MISSING_COMPANY_NAME" } });
    }

    console.log(`[JOB_TIPS] Requesting tips for: ${company_name} - ${job_position || 'All positions'}`);

    const response = await axios.post(
      `${process.env.MCP_RECS_BASE}/tools/get_job_tips`,
      { company_name, job_position },
      { timeout: 10000 }
    );

    if (response.data && response.data.success) {
      res.json({
        success: true,
        company_name,
        job_position: job_position || 'All positions',
        data: response.data,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({ error: { code: "JOB_TIPS_FAILED" } });
    }

  } catch (error) {
    console.error("[JOB_TIPS] Error:", error.message);
    res.status(500).json({ error: { code: "JOB_TIPS_FAILED" } });
  }
});

// 종합 취업 정보 API (기업정보 + 자소서 + 꿀팁 통합)
app.post("/api/comprehensive-job-info", async (req, res) => {
  try {
    const { company_name, job_position } = req.body;

    if (!company_name) {
      return res.status(400).json({ error: { code: "MISSING_COMPANY_NAME" } });
    }

    console.log(`[COMPREHENSIVE] Requesting comprehensive info for: ${company_name} - ${job_position || 'All positions'}`);

    // 병렬로 3개의 API 호출
    const [companyInfo, jobEssays, jobTips] = await Promise.allSettled([
      axios.post(`${process.env.MCP_RECS_BASE}/tools/get_company_reviews`, { company_name }, { timeout: 8000 }),
      axios.post(`${process.env.MCP_RECS_BASE}/tools/get_job_essays`, { company_name, job_position }, { timeout: 8000 }),
      axios.post(`${process.env.MCP_RECS_BASE}/tools/get_job_tips`, { company_name, job_position }, { timeout: 8000 })
    ]);

    const result = {
      success: true,
      company_name,
      job_position: job_position || 'All positions',
      timestamp: new Date().toISOString(),
      data: {
        company_info: companyInfo.status === 'fulfilled' && companyInfo.value.data?.success ? companyInfo.value.data : null,
        job_essays: jobEssays.status === 'fulfilled' && jobEssays.value.data?.success ? jobEssays.value.data : null,
        job_tips: jobTips.status === 'fulfilled' && jobTips.value.data?.success ? jobTips.value.data : null
      }
    };

    res.json(result);

  } catch (error) {
    console.error("[COMPREHENSIVE] Error:", error.message);
    res.status(500).json({ error: { code: "COMPREHENSIVE_INFO_FAILED" } });
  }
});

/* -------------------- GPT MCP 기반 맞춤 면접 -------------------- */
/**
 * @swagger
 * /session/interview:
 *   get:
 *     summary: GPT MCP 기반 회사별 맞춤 면접 질문 생성
 *     tags: [Interview]
 *     parameters:
 *       - in: query
 *         name: user_id
 *         required: true
 *         schema:
 *           type: integer
 *         description: 사용자 ID
 *       - in: query
 *         name: jobId
 *         required: true
 *         schema:
 *           type: string
 *         description: 채용공고 ID
 *       - in: query
 *         name: questionCount
 *         schema:
 *           type: integer
 *           default: 8
 *         description: 생성할 질문 개수
 *       - in: query
 *         name: difficulty
 *         schema:
 *           type: string
 *           enum: [beginner, intermediate, advanced, mixed]
 *           default: mixed
 *         description: 면접 난이도 레벨
 *     responses:
 *       200:
 *         description: GPT 기반 맞춤 면접 질문 생성 완료
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 questions:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: integer
 *                       question:
 *                         type: string
 *                       category:
 *                         type: string
 *                       difficulty:
 *                         type: string
 *                       expected_answer_points:
 *                         type: array
 *                         items:
 *                           type: string
 *                       tips:
 *                         type: string
 *                 interview_strategy:
 *                   type: object
 *                   properties:
 *                     company_focus:
 *                       type: string
 *                     key_preparation_areas:
 *                       type: array
 *                       items:
 *                         type: string
 *                     personalization_insights:
 *                       type: string
 *                 job_match_analysis:
 *                   type: object
 *                   properties:
 *                     strength_areas:
 *                       type: array
 *                       items:
 *                         type: string
 *                     growth_opportunities:
 *                       type: array
 *                       items:
 *                         type: string
 *       400:
 *         description: 필수 파라미터 누락 또는 잘못된 요청
 *       404:
 *         description: 채용공고를 찾을 수 없음
 *       500:
 *         description: 서버 오류
 */
app.get("/session/interview", async (req, res) => {
  try {
    const { user_id, jobId, questionCount = 8, difficulty = 'mixed' } = req.query;
    const s = ensureSession(String(user_id));

    if (!s.user) {
      return res.status(400).json({ error: { code: "NO_USER_PROFILE" } });
    }

    const job = s.jobs.find(j => j.job_id === jobId);
    if (!job) return res.status(404).json({ error: { code: "JOB_NOT_FOUND" } });

    const company = s.companies.find(c => c.company_id === job.company_id) || null;

    console.log(`[GPT-INTERVIEW] Generating ${questionCount} questions for ${job.company} - ${job.title} (difficulty: ${difficulty})`);

    const { data } = await axios.post(
      `${process.env.MCP_RECS_BASE}/tools/gpt_generate_interview`,
      {
        sessionId: String(user_id),
        userProfile: {
          skills: s.user.skills || [],
          years: s.user.years,
          region: s.user.region,
          role: s.user.role,
          resumeHints: s.user.resumeHints,
          resumeText: s.user.resumeText
        },
        jobDetails: {
          job_id: job.job_id,
          title: job.title,
          company: job.company,
          skills: job.skills || [],
          region: job.region,
          years_min: job.years_min,
          years_max: job.years_max,
          description: job.description,
          requirements: job.requirements || null
        },
        companyInfo: company ? {
          company_id: company.company_id,
          name: company.name,
          overview: company.overview,
          culture: company.culture,
          values: company.values
        } : null,
        interviewConfig: {
          questionCount: Math.min(Number(questionCount) || 8, 15),
          difficulty: difficulty,
          includeCompanySpecific: !!company,
          includeTechnicalQuestions: true,
          includeBehavioralQuestions: true,
          includeRoleSpecificQuestions: true
        }
      },
      { timeout: 35000 }
    );

    if (data?.interview) {
      res.json({
        success: true,
        job_info: {
          job_id: job.job_id,
          title: job.title,
          company: job.company,
          skills: job.skills
        },
        questions: data.interview.questions || [],
        interview_strategy: data.interview.strategy || null,
        job_match_analysis: data.interview.job_match_analysis || null,
        generated_at: new Date().toISOString(),
        generation_method: 'gpt_mcp_enhanced'
      });
    } else {
      res.status(500).json({ error: { code: "INTERVIEW_NO_DATA" } });
    }

  } catch (e) {
    console.error("[GPT-INTERVIEW] Error:", e.response?.data || e.message);
    res.status(500).json({ error: { code: "GPT_INTERVIEW_FAILED" } });
  }
});

/* -------------------- 피드백(개인화) -------------------- */
app.post("/session/feedback", async (req, res) => {
  try {
    const { sessionId, type, company, skill } = req.body || {};
    ensureSession(sessionId);

    const { data } = await axios.post(`${process.env.MCP_RECS_BASE}/tools/feedback`, {
      sessionId,
      type,
      target: { company, skill },
    });
    res.json(data);
  } catch (e) {
    res.status(400).json({ error: { code: "FEEDBACK_FAILED" } });
  }
});

/* -------------------- 데모 데이터 설정 API -------------------- */
/**
 * @swagger
 * /api/setup-demo-data:
 *   post:
 *     summary: Create demo data for prototype testing
 *     tags: [Demo]
 *     responses:
 *       200:
 *         description: Demo data created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 message:
 *                   type: string
 *                 created:
 *                   type: object
 */
app.post("/api/setup-demo-data", async (req, res) => {
  try {
    console.log('[DEMO] Setting up demo data...');

    // 데모 회사 데이터
    const demoCompanies = [
      { id: 'demo_company_1', name: '네이버', industry: 'IT', location: '서울' },
      { id: 'demo_company_2', name: '카카오', industry: 'IT', location: '서울' },
      { id: 'demo_company_3', name: '삼성전자', industry: 'IT', location: '서울' },
      { id: 'demo_company_4', name: '엔씨소프트', industry: '게임', location: '서울' },
      { id: 'demo_company_5', name: '쿠팡', industry: 'IT', location: '서울' }
    ];

    // 데모 채용공고 데이터
    const demoJobs = [
      {
        id: 'job_1',
        companyId: 'demo_company_1',
        companyName: '네이버',
        title: '백엔드 개발자',
        requiredSkills: ['Node.js', 'Express', 'MySQL', 'AWS'],
        location: '서울',
        experienceLevel: '신입',
        jobType: 'IT',
        description: 'Node.js 기반 백엔드 시스템 개발',
        salary: '3500-5000만원'
      },
      {
        id: 'job_2',
        companyId: 'demo_company_2',
        companyName: '카카오',
        title: '프론트엔드 개발자',
        requiredSkills: ['React', 'JavaScript', 'TypeScript', 'CSS'],
        location: '서울',
        experienceLevel: '신입',
        jobType: 'IT',
        description: 'React 기반 웹 프론트엔드 개발',
        salary: '3000-4500만원'
      },
      {
        id: 'job_3',
        companyId: 'demo_company_3',
        companyName: '삼성전자',
        title: '빅데이터 엔지니어',
        requiredSkills: ['Python', 'Spark', 'Hadoop', 'SQL'],
        location: '서울',
        experienceLevel: '경력 1-3년',
        jobType: '빅데이터',
        description: '대용량 데이터 처리 및 분석 시스템 구축',
        salary: '4000-6000만원'
      },
      {
        id: 'job_4',
        companyId: 'demo_company_4',
        companyName: '엔씨소프트',
        title: '게임 클라이언트 개발자',
        requiredSkills: ['C++', 'Unity', 'C#', 'DirectX'],
        location: '서울',
        experienceLevel: '신입',
        jobType: 'IT',
        description: '모바일/PC 게임 클라이언트 개발',
        salary: '3500-5500만원'
      },
      {
        id: 'job_5',
        companyId: 'demo_company_5',
        companyName: '쿠팡',
        title: '데이터 사이언티스트',
        requiredSkills: ['Python', 'TensorFlow', 'PyTorch', 'SQL'],
        location: '서울',
        experienceLevel: '경력 2-5년',
        jobType: '빅데이터',
        description: '머신러닝 모델 개발 및 데이터 분석',
        salary: '5000-8000만원'
      }
    ];

    // 데모 사용자 데이터
    const demoUsers = [
      {
        id: 'demo_user_1',
        email: 'demo1@test.com',
        name: '김개발',
        skills: ['Node.js', 'React', 'MySQL'],
        preferredLocation: '서울',
        experienceLevel: '신입',
        preferredJobType: 'IT'
      },
      {
        id: 'demo_user_2',
        email: 'demo2@test.com',
        name: '이데이터',
        skills: ['Python', 'SQL', 'TensorFlow'],
        preferredLocation: '서울',
        experienceLevel: '경력 1-3년',
        preferredJobType: '빅데이터'
      }
    ];

    // 전역 변수에 저장 (실제로는 DB에 저장해야 함)
    global.demoData = {
      companies: demoCompanies,
      jobs: demoJobs,
      users: demoUsers,
      currentUser: null
    };

    console.log('[DEMO] Demo data created successfully');
    res.json({
      success: true,
      message: 'Demo data created successfully',
      created: {
        companies: demoCompanies.length,
        jobs: demoJobs.length,
        users: demoUsers.length
      }
    });

  } catch (error) {
    console.error('[DEMO] Error setting up demo data:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to setup demo data',
      details: error.message
    });
  }
});

/**
 * @swagger
 * /api/demo-login:
 *   post:
 *     summary: Demo login without OAuth
 *     tags: [Demo]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               userId:
 *                 type: string
 *                 enum: [demo_user_1, demo_user_2]
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                 user:
 *                   type: object
 */
app.post("/api/demo-login", async (req, res) => {
  try {
    const { userId } = req.body;

    if (!global.demoData) {
      return res.status(400).json({
        success: false,
        error: 'Demo data not initialized. Call /api/setup-demo-data first.'
      });
    }

    const user = global.demoData.users.find(u => u.id === userId);
    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'Demo user not found'
      });
    }

    global.demoData.currentUser = user;
    console.log(`[DEMO] User logged in: ${user.name} (${user.email})`);

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        skills: user.skills,
        preferredLocation: user.preferredLocation,
        experienceLevel: user.experienceLevel,
        preferredJobType: user.preferredJobType
      }
    });

  } catch (error) {
    console.error('[DEMO] Login error:', error);
    res.status(500).json({
      success: false,
      error: 'Demo login failed',
      details: error.message
    });
  }
});

/**
 * @swagger
 * /api/demo-status:
 *   get:
 *     summary: Check demo system status
 *     tags: [Demo]
 *     responses:
 *       200:
 *         description: Demo system status
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 initialized:
 *                   type: boolean
 *                 currentUser:
 *                   type: object
 *                 dataCount:
 *                   type: object
 */
app.get("/api/demo-status", (req, res) => {
  const isInitialized = !!global.demoData;

  res.json({
    initialized: isInitialized,
    currentUser: isInitialized ? global.demoData.currentUser : null,
    dataCount: isInitialized ? {
      companies: global.demoData.companies.length,
      jobs: global.demoData.jobs.length,
      users: global.demoData.users.length
    } : null
  });
});

/* -------------------- 헬스 체크 -------------------- */
app.get("/health", (req, res) => res.json({ ok: true, ts: Date.now() }));
app.get("/api/health", (req, res) => res.json({ ok: true, ts: Date.now() }));

// ==== 404 핸들러 (마지막) ====
app.use((req, res) => {
  res.status(404).json({ error: 'Not Found', path: req.originalUrl });
});


/* -------------------- 서버 시작 -------------------- */
// 변경: IPv4 로컬호스트에 확실히 바인딩
// --- listen

app.listen(PORT, HOST, () => {
  console.log(`[BOOT] Listening on http://${HOST}:${PORT} (NODE_ENV=${process.env.NODE_ENV})`);
});
